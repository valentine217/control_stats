function default_css_events(){
	/* default display for events */
	$("#events-opn,#details,#details-kpsule,.de-kp-hid").hide();
}

function default_css_timers(){
	/* default display for timers */
    $("#timers-opn").hide();
}

function trackEvent( info ) {
	console.log(info);
}

$(document).ready(function(){

	// set default 
	default_css_events();
	default_css_timers();
	
	/* click and change */
	// events
	$("#events-cls").click(function(){
		//close
		$("#ge-de-dek,#general,#details,#details-kpsule,#events-cls").hide();
		// change display icon
		$("#events-opn").show();
	});
	$("#events-opn").click(function(){
		$("#ge-de-dek,#general,#details,#details-kpsule,#events-cls").show();
		default_css_events();
		// change display icon
		$("#events-opn").hide();
	});
	
	// general
	$("#ge-dsp").click(function(){
		//display
		$("#general").show();
		//hide
		$("#details,#details-kpsule").hide();
		//all details kpsule closed
		$(".de-kp-hid").hide();
		$(".de-kp-opn").show();
	});
	
	// details
	$("#de-dsp").click(function(){
		//display
		$("#details").show();
		//hide
		$("#general,#details-kpsule").hide();
		//all details kpsule closed
		$(".de-kp-hid").hide();
		$(".de-kp-opn").show();
	});
	
	// details kpsule
	$("#dek-dsp").click(function(){
		//display
		$("#details-kpsule").show();
		$(".de-kp-hid").hide();
		$(".de-kp-opn").show();
		//hide
		$("#general,#details,.de-kp-hide").hide();
	});
	$(".de-kp-hid").click(function(){
		//hide
		$(this).hide();
		$(this).closest("tr").next().hide();
		$(this).closest("tr").next().next().hide();
		//change display icon
		$(this).prev().show();
		//return css
		$(this).closest("tr").css("background-color", "#231f20");
		$(this).parent().prev().find("p").css("background-color", "#231f20").css("color","#c8c8c8");
	});
	$(".de-kp-opn").click(function(){
		//open
		$(this).next().show();
		$(this).closest("tr").next().show();
		$(this).closest("tr").next().next().show();
		// change display icon
		$(this).hide();
		//change css
		$(this).closest("tr").css("background-color", "#a6a8ab");
		$(this).parent().prev().find("p").css("background-color", "#a6a8ab").css("color","#fff");
	});
	
	// timer detials
	$("#timers-cls").click(function(){
		//close
		$("#timers-detail,#timers-cls").hide();
		// change display icon
		$("#timers-opn").show();
	});
	$("#timers-opn").click(function(){
		$("#timers-detail,#timers-cls").show();
		// change display icon
		$("#timers-opn").hide();
	});

	$("#ctl-cls").click(function(){
		$("#control-stats").remove();
	});
});